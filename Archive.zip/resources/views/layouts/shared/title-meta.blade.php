<meta charset="utf-8" />
<title> لوحه تحكم - امنك </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="" name="description" />
<meta content="Coderthemes" name="author" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Access-Control-Allow-Origin" content="*">
<link href='https://fonts.googleapis.com/css?family=Cairo' rel='stylesheet'>

<!-- App favicon -->
<link rel="shortcut icon" href="{{asset('assets/images/favicon.ico')}}">

<style>
    table.dataTable thead th, 
    table.dataTable thead td, 
    table.dataTable tfoot th, 
    table.dataTable tfoot td {
        text-align: right !important; /* تغيير المحاذاة */
    }
</style>

